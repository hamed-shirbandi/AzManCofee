﻿

use following setting on your app config file 

  <appSettings>
    <add key="AzManConnectionStringName" value="MyAzManConnectionStringName" />
    <add key="AzManAppName" value="MyAppName" />
    <add key="AzManStorageName" value="MyAppStore" />
    <add key="AzManDomainName" value="MyDomain" />
    <add key="AzManBypass" value="true" />
	.
	.
	.

 </appSettings>

 for more info about AzManCofee visit this page https://github.com/hamed-shirbandi/AzManCofee